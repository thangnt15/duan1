<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/quanlyloaihang.css">
    <title>Danh muc SP</title>
</head>
<body>
    <h1>a</h1>
</body>
</html>