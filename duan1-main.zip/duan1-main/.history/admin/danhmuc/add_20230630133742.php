<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addloaihang.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>
            Thêm danh mục loại hàng
        </h1>
        <input type="text" name="tenloai" autocomplete="off" required >
     <label for="text2" class="label-name">
                                <span class="content-name">
                                    Tên danh mục
                                </span>
                            </label> <br>
        <a href="index.php?act=adddm"><input type="button" value="Nhập thêm"></a>
    </div>
</body>
</html>