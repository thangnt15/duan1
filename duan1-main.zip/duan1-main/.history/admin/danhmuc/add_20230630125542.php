
<div class="container-">

<!-- Viết code ở đây -->
<?php

?>


<h1>Quản lý danh mục</h1>

<div>
<table class="content-table">
<thead>
<tr>

<th>Mã loại</th>
<th>Tên loại</th>
<th>Xử lý</th>
</tr>
</thead>
