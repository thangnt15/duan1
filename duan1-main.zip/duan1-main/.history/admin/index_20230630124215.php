<?php

    include "header.php";

    if





    include "home.php";
    include "footer.php"

?>