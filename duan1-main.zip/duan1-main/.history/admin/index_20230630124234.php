<?php

    include "header.php";

    if(isset($_GET['act'])) {
        
    }





    include "home.php";
    include "footer.php"

?>