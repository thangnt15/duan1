<?

    include "header.php";
    include "home.php";
    in

?>