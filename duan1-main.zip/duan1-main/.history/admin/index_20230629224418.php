<?

    include "header.php";
    include "home"

?>