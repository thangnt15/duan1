<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/admin.css">
  <title>Document</title>
</head>
<style>
  a {
    display: block;
  }
</style>
<body>
    <div id="control">
      <div class="control-left">
        <a href="index.php" style="text-decoration: none; font-size: 25px; color: #c7fa7c; font-weight: bold; line-height: 80px;">
          Bảng điều khiển
        </a>
        <div class="line">

        </div>
        <div class="option">
          <h2 style="margin: 20px 0;">
            Chức năng
          </h2>
          <div class="line">
          </div>
          <div class="options" style="margin: 20px 0;">
            <a href="index.php?act=qldm">Quản lý danh mục </a>
            <a href="index.php?act=qlsp">Quản lý hàng hóa </a>
            <a href="index.php?act=dskh">Quản lý tài khoản </a>
            <a href="index.php?act=dsdh">Danh sách đơn hàng </a>
            <a href="index.php?act=dsbl">Quản lý bình luận </a>
            <a href="index.php?act=thongke">Quản lý thống kê </a>
          </div>
          <div class="line">
          
          </div>
        </div>
        <a class="tt" href="./view/index.php">
          Quay lại giao diện
        </a>
        <div class="line">
          
        </div>
      </div>
    </div>
    
    
</body>
</html>